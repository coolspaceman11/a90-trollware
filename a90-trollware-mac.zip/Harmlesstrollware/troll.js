ObjC.import("Cocoa");

const app = Application.currentApplication();
app.includeStandardAdditions = true;

const NSApp =
    $.NSApplication.sharedApplication;

NSApp.setActivationPolicy(
    $.NSApplicationActivationPolicyAccessory
);

// ============================================================
// PATHS
// ============================================================

const HOME =
    ObjC.unwrap(
        $.NSHomeDirectory()
    );

const BASE =
    HOME + "/Desktop/Harmlesstrollware";

const FILES = {

    spawnSound:
        BASE + "/a-90-warning.mp3",

    attackSound:
        BASE + "/attack.wav",

    postSound:
        BASE + "/230b23a1-8641-46ea-a62d-c0ef5fe7ce64.wav",

    ambience:
        BASE + "/layer3.wav",

    spawnStatic:
        BASE + "/static2png.png",

    spawnFace:
        BASE + "/ransom_idle(1).png",

    stop:
        BASE + "/stop_sign.png",

    attackStatic:
        BASE + "/static1.png",

    attackFace:
        BASE + "/ransom_attack.png",

    idiot:
        BASE + "/idiot.png",

    taunt:
        BASE + "/taunt2.jpg",

    download:
        BASE + "/taunt3.jpeg",

    shake1:
        BASE + "/shake_popup_1.png",

    shake2:
        BASE + "/shake_popup_2.png",

    desktopStop:
        BASE + "/desktop_stop.png",

    shutdownFace:
        BASE + "/shutdown_face.png"
};

// ============================================================
// TIMING
// ============================================================

const SPAWN_FACE_AT =
    0.30;

const STOP_AT =
    0.65;

const SPAWN_DURATION =
    2.23;

const DESKTOP_GAP =
    0.40;

const ATTACK_VISUAL =
    0.60;

// Start download 0.5 sec before attack.wav ends.
const DOWNLOAD_LEAD =
    0.50;

// NEW: download only lasts 2 sec total.
const DOWNLOAD_DURATION =
    2.0;

// NEW: shutdown starts 3 sec after download reaches 100%.
const SHUTDOWN_DELAY =
    3.0;

// Final replacement-face jumpscare duration.
const FINAL_JUMP_DURATION =
    0.65;

// Start final jump so it ENDS approximately
// when the 3-second shutdown point is reached.
const FINAL_JUMP_LEAD =
    FINAL_JUMP_DURATION;

// Maximum popup lifetime.
const POPUP_DURATION =
    140.0;

const TELEPORT_INTERVAL =
    1.0;

// Reduced JXA animation frequency for stability.
const DVD_FRAME_TIME =
    0.05;

const SHAKE_FRAME_TIME =
    0.07;

// ============================================================
// WINDOW LEVELS
// ============================================================

const FLOAT_LEVEL =
    Number(
        $.NSFloatingWindowLevel
    );

const DOWNLOAD_LEVEL =
    FLOAT_LEVEL + 30;

const STOP_LEVEL =
    FLOAT_LEVEL + 40;

const POPUP_LEVEL =
    FLOAT_LEVEL + 50;

const FULLSCREEN_LEVEL =
    FLOAT_LEVEL + 100;

// ============================================================
// LOGGING
// ============================================================

function log(text) {

    console.log(
        "[A90] " + text
    );
}

// ============================================================
// GENERAL HELPERS
// ============================================================

function shellQuote(text) {

    return "'" +
        String(text).replace(
            /'/g,
            "'\\''"
        ) +
        "'";
}

function pump(seconds) {

    $.NSRunLoop.currentRunLoop
        .runUntilDate(
            $.NSDate
                .dateWithTimeIntervalSinceNow(
                    seconds
                )
        );
}

function exists(path) {

    return Boolean(
        ObjC.unwrap(
            $.NSFileManager
                .defaultManager
                .fileExistsAtPath(
                    $(path)
                )
        )
    );
}

function randomBetween(
    min,
    max
) {

    if (max <= min) {
        return min;
    }

    return (
        min +
        Math.random() *
        (max - min)
    );
}

function loadImage(path) {

    const image =
        $.NSImage.alloc
            .initWithContentsOfFile(
                $(path)
            );

    if (!image) {

        throw new Error(
            "Unable to load image:\n" +
            path
        );
    }

    return image;
}

function hideWindow(win) {

    if (!win) {
        return;
    }

    try {

        win.orderOut(
            null
        );

    } catch (e) {}
}

function isVisible(win) {

    if (!win) {
        return false;
    }

    try {

        return Boolean(
            ObjC.unwrap(
                win.isVisible
            )
        );

    } catch (e) {

        return false;
    }
}

// ============================================================
// FILE CHECK
// ============================================================

Object.keys(FILES).forEach(
    function (key) {

        if (!exists(FILES[key])) {

            throw new Error(
                "Missing required file:\n\n" +
                FILES[key]
            );
        }
    }
);

log(
    "All files found."
);

// ============================================================
// AUDIO
//
// IMPORTANT:
//
// Nothing here changes system volume.
// afplay uses the Mac's CURRENT volume.
// ============================================================

function playSound(path) {

    try {

        const command =
            "/usr/bin/afplay " +
            shellQuote(path) +
            " >/dev/null 2>&1 & echo $!";

        const result =
            app.doShellScript(
                command
            );

        return (
            parseInt(
                result,
                10
            ) || 0
        );

    } catch (e) {

        log(
            "Audio failed: " +
            String(e)
        );

        return 0;
    }
}

function stopSound(pid) {

    if (!pid) {
        return;
    }

    try {

        app.doShellScript(
            "/bin/kill " +
            String(pid) +
            " >/dev/null 2>&1 || true"
        );

    } catch (e) {}
}

function audioDuration(path) {

    try {

        const result =
            app.doShellScript(
                "/usr/bin/afinfo " +
                shellQuote(path) +
                " | /usr/bin/awk " +
                "'/estimated duration/ {print $3; exit}'"
            );

        const duration =
            parseFloat(
                result
            );

        if (
            Number.isFinite(duration) &&
            duration > 0
        ) {

            return duration;
        }

    } catch (e) {}

    return 2.61;
}

// ============================================================
// BASIC WINDOW
// ============================================================

function createBorderlessWindow(
    frame,
    level
) {

    const win =
        $.NSWindow.alloc
            .initWithContentRectStyleMaskBackingDefer(
                frame,
                Number(
                    $.NSWindowStyleMaskBorderless
                ),
                $.NSBackingStoreBuffered,
                false
            );

    win.setReleasedWhenClosed(
        false
    );

    win.setLevel(
        level
    );

    return win;
}

// ============================================================
// SPAWN
// ============================================================

function showSpawn() {

    log(
        "Spawn phase."
    );

    const frame =
        $.NSScreen.mainScreen.frame;

    const width =
        Number(
            frame.size.width
        );

    const height =
        Number(
            frame.size.height
        );

    const win =
        createBorderlessWindow(
            frame,
            FULLSCREEN_LEVEL
        );

    const root =
        win.contentView;

    // ========================================================
    // RED STATIC
    // ========================================================

    const background =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    0,
                    0,
                    width,
                    height
                )
            );

    background.setImage(
        loadImage(
            FILES.spawnStatic
        )
    );

    background.setImageScaling(
        $.NSImageScaleAxesIndependently
    );

    root.addSubview(
        background
    );

    // ========================================================
    // FACE
    // ========================================================

    const faceSize =
        520;

    const faceBaseX =
        (
            width -
            faceSize
        ) / 2;

    const faceBaseY =
        (
            height -
            faceSize
        ) / 2;

    const face =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    faceBaseX,
                    faceBaseY,
                    faceSize,
                    faceSize
                )
            );

    face.setImage(
        loadImage(
            FILES.spawnFace
        )
    );

    face.setImageScaling(
        $.NSImageScaleProportionallyUpOrDown
    );

    face.setHidden(
        true
    );

    root.addSubview(
        face
    );

    // ========================================================
    // STOP
    // ========================================================

    const stopSize =
        285;

    const stop =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    (
                        width -
                        stopSize
                    ) / 2,

                    (
                        height -
                        stopSize
                    ) / 2,

                    stopSize,
                    stopSize
                )
            );

    stop.setImage(
        loadImage(
            FILES.stop
        )
    );

    stop.setImageScaling(
        $.NSImageScaleProportionallyUpOrDown
    );

    stop.setHidden(
        true
    );

    root.addSubview(
        stop
    );

    // ========================================================
    // SHOW
    // ========================================================

    win.makeKeyAndOrderFront(
        null
    );

    NSApp.activateIgnoringOtherApps(
        true
    );

    pump(
        0.05
    );

    const spawnPID =
        playSound(
            FILES.spawnSound
        );

    const start =
        Date.now();

    let faceShown =
        false;

    let stopShown =
        false;

    while (
        (
            Date.now() -
            start
        ) / 1000 <
        SPAWN_DURATION
    ) {

        const elapsed =
            (
                Date.now() -
                start
            ) / 1000;

        // ----------------------------------------------------
        // FACE
        // ----------------------------------------------------

        if (
            elapsed >=
            SPAWN_FACE_AT &&
            elapsed <
            STOP_AT
        ) {

            if (!faceShown) {

                faceShown =
                    true;

                face.setHidden(
                    false
                );
            }

            face.setFrameOrigin(
                $.NSMakePoint(

                    faceBaseX +
                        randomBetween(
                            -10,
                            10
                        ),

                    faceBaseY +
                        randomBetween(
                            -10,
                            10
                        )
                )
            );
        }

        // ----------------------------------------------------
        // STOP REPLACES FACE
        // ----------------------------------------------------

        if (
            elapsed >=
            STOP_AT &&
            !stopShown
        ) {

            stopShown =
                true;

            face.setHidden(
                true
            );

            stop.setHidden(
                false
            );
        }

        pump(
            0.025
        );
    }

    stopSound(
        spawnPID
    );

    hideWindow(
        win
    );

    pump(
        0.05
    );
}

// ============================================================
// ATTACK
// ============================================================

function showAttack() {

    log(
        "Attack phase."
    );

    const frame =
        $.NSScreen.mainScreen.frame;

    const width =
        Number(
            frame.size.width
        );

    const height =
        Number(
            frame.size.height
        );

    const win =
        createBorderlessWindow(
            frame,
            FULLSCREEN_LEVEL
        );

    const root =
        win.contentView;

    // ========================================================
    // STATIC
    // ========================================================

    const background =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    0,
                    0,
                    width,
                    height
                )
            );

    background.setImage(
        loadImage(
            FILES.attackStatic
        )
    );

    background.setImageScaling(
        $.NSImageScaleAxesIndependently
    );

    root.addSubview(
        background
    );

    // ========================================================
    // ATTACK FACE
    // ========================================================

    const faceSize =
        600;

    const faceBaseX =
        (
            width -
            faceSize
        ) / 2;

    const faceBaseY =
        (
            height -
            faceSize
        ) / 2;

    const face =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    faceBaseX,
                    faceBaseY,
                    faceSize,
                    faceSize
                )
            );

    face.setImage(
        loadImage(
            FILES.attackFace
        )
    );

    face.setImageScaling(
        $.NSImageScaleProportionallyUpOrDown
    );

    root.addSubview(
        face
    );

    win.makeKeyAndOrderFront(
        null
    );

    NSApp.activateIgnoringOtherApps(
        true
    );

    pump(
        0.05
    );

    const duration =
        audioDuration(
            FILES.attackSound
        );

    log(
        "Attack audio length: " +
        duration.toFixed(2) +
        " sec"
    );

    const started =
        Date.now();

    const pid =
        playSound(
            FILES.attackSound
        );

    while (
        (
            Date.now() -
            started
        ) / 1000 <
        ATTACK_VISUAL
    ) {

        face.setFrameOrigin(
            $.NSMakePoint(

                faceBaseX +
                    randomBetween(
                        -12,
                        12
                    ),

                faceBaseY +
                    randomBetween(
                        -12,
                        12
                    )
            )
        );

        pump(
            0.025
        );
    }

    hideWindow(
        win
    );

    pump(
        0.05
    );

    return {

        started:
            started,

        duration:
            duration,

        pid:
            pid
    };
}

// ============================================================
// NORMAL TITLED POPUP
// ============================================================

function createPopup(
    title,
    imagePath,
    width,
    height,
    x,
    y
) {

    const style =
        Number(
            $.NSWindowStyleMaskTitled
        ) |
        Number(
            $.NSWindowStyleMaskClosable
        );

    const win =
        $.NSWindow.alloc
            .initWithContentRectStyleMaskBackingDefer(
                $.NSMakeRect(
                    x,
                    y,
                    width,
                    height
                ),
                style,
                $.NSBackingStoreBuffered,
                false
            );

    win.setReleasedWhenClosed(
        false
    );

    win.setTitle(
        $(title)
    );

    win.setLevel(
        POPUP_LEVEL
    );

    const image =
        $.NSImageView.alloc
            .initWithFrame(
                win.contentView.bounds
            );

    image.setImage(
        loadImage(
            imagePath
        )
    );

    image.setImageScaling(
        $.NSImageScaleProportionallyUpOrDown
    );

    image.setAutoresizingMask(
        Number(
            $.NSViewWidthSizable
        ) |
        Number(
            $.NSViewHeightSizable
        )
    );

    win.contentView.addSubview(
        image
    );

    return win;
}

// ============================================================
// STOP-SIGN OVERLAY WINDOW
//
// CLICK-THROUGH.
// Does not stop Dock/desktop clicks.
// ============================================================

function createStopOverlay(
    x,
    y,
    size
) {

    const win =
        createBorderlessWindow(
            $.NSMakeRect(
                x,
                y,
                size,
                size
            ),
            STOP_LEVEL
        );

    win.setOpaque(
        false
    );

    win.setBackgroundColor(
        $.NSColor.clearColor
    );

    win.setIgnoresMouseEvents(
        true
    );

    const image =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    0,
                    0,
                    size,
                    size
                )
            );

    image.setImage(
        loadImage(
            FILES.desktopStop
        )
    );

    image.setImageScaling(
        $.NSImageScaleProportionallyUpOrDown
    );

    win.contentView.addSubview(
        image
    );

    win.orderFront(
        null
    );

    return win;
}

// ============================================================
// CREATE ALL DOCK / DESKTOP STOP SIGNS
// ============================================================

function createStopSigns() {

    log(
        "Creating Dock/desktop STOP overlays."
    );

    const frame =
        $.NSScreen.mainScreen.frame;

    const x0 =
        Number(
            frame.origin.x
        );

    const y0 =
        Number(
            frame.origin.y
        );

    const width =
        Number(
            frame.size.width
        );

    const height =
        Number(
            frame.size.height
        );

    const stops =
        [];

    // ========================================================
    // BOTTOM DOCK
    // ========================================================

    const dockSize =
        82;

    const dockFractions = [
        0.20,
        0.30,
        0.40,
        0.50,
        0.60,
        0.70,
        0.80
    ];

    dockFractions.forEach(
        function (fraction) {

            stops.push(
                createStopOverlay(

                    x0 +
                    width *
                    fraction -
                    dockSize / 2,

                    y0 + 6,

                    dockSize
                )
            );
        }
    );

    // ========================================================
    // DESKTOP ICON AREA
    //
    // macOS normally places desktop files/icons down the
    // right side, so place STOP signs there.
    // ========================================================

    const desktopSize =
        74;

    const rightX =
        x0 +
        width -
        desktopSize -
        15;

    const desktopYs = [
        height - 145,
        height - 245,
        height - 345,
        height - 445,
        height - 545
    ];

    desktopYs.forEach(
        function (relativeY) {

            if (
                relativeY >
                60
            ) {

                stops.push(
                    createStopOverlay(
                        rightX,
                        y0 +
                        relativeY,
                        desktopSize
                    )
                );
            }
        }
    );

    return stops;
}

// ============================================================
// DOWNLOAD OVERLAY
//
// No CALayer use.
// ============================================================

function createDownloadOverlay() {

    log(
        "Creating download overlay."
    );

    const frame =
        $.NSScreen.mainScreen.frame;

    const width =
        Number(
            frame.size.width
        );

    const height =
        Number(
            frame.size.height
        );

    const win =
        createBorderlessWindow(
            frame,
            DOWNLOAD_LEVEL
        );

    win.setOpaque(
        false
    );

    win.setBackgroundColor(
        $.NSColor.clearColor
    );

    win.setIgnoresMouseEvents(
        true
    );

    const root =
        win.contentView;

    // ========================================================
    // 30% GLITCH IMAGE
    // ========================================================

    const glitchBaseX =
        -10;

    const glitchBaseY =
        -10;

    const glitch =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    glitchBaseX,
                    glitchBaseY,
                    width + 20,
                    height + 20
                )
            );

    glitch.setImage(
        loadImage(
            FILES.download
        )
    );

    glitch.setImageScaling(
        $.NSImageScaleAxesIndependently
    );

    glitch.setAlphaValue(
        0.30
    );

    root.addSubview(
        glitch
    );

    // ========================================================
    // CENTER PANEL BACKGROUND
    // ========================================================

    const panelWidth =
        Math.min(
            650,
            width - 80
        );

    const panelHeight =
        125;

    const panelX =
        (
            width -
            panelWidth
        ) / 2;

    const panelY =
        (
            height -
            panelHeight
        ) / 2;

    const panel =
        $.NSTextField.alloc
            .initWithFrame(
                $.NSMakeRect(
                    panelX,
                    panelY,
                    panelWidth,
                    panelHeight
                )
            );

    panel.setStringValue(
        $("")
    );

    panel.setEditable(
        false
    );

    panel.setSelectable(
        false
    );

    panel.setBezeled(
        false
    );

    panel.setDrawsBackground(
        true
    );

    panel.setBackgroundColor(
        $.NSColor
            .colorWithCalibratedWhiteAlpha(
                0.0,
                0.80
            )
    );

    root.addSubview(
        panel
    );

    // ========================================================
    // TEXT
    // ========================================================

    const label =
        $.NSTextField.alloc
            .initWithFrame(
                $.NSMakeRect(
                    panelX + 20,
                    panelY + 72,
                    panelWidth - 40,
                    32
                )
            );

    label.setStringValue(
        $(
            "DOWNLOADING A-90... (0%)"
        )
    );

    label.setEditable(
        false
    );

    label.setSelectable(
        false
    );

    label.setBezeled(
        false
    );

    label.setDrawsBackground(
        false
    );

    label.setAlignment(
        $.NSTextAlignmentCenter
    );

    label.setTextColor(
        $.NSColor.whiteColor
    );

    label.setFont(
        $.NSFont
            .boldSystemFontOfSize(
                22
            )
    );

    root.addSubview(
        label
    );

    // ========================================================
    // BAR BACKGROUND
    // ========================================================

    const barX =
        panelX + 35;

    const barY =
        panelY + 31;

    const barWidth =
        panelWidth - 70;

    const barHeight =
        24;

    const barBackground =
        $.NSTextField.alloc
            .initWithFrame(
                $.NSMakeRect(
                    barX,
                    barY,
                    barWidth,
                    barHeight
                )
            );

    barBackground.setStringValue(
        $("")
    );

    barBackground.setEditable(
        false
    );

    barBackground.setSelectable(
        false
    );

    barBackground.setBezeled(
        false
    );

    barBackground.setDrawsBackground(
        true
    );

    barBackground.setBackgroundColor(
        $.NSColor
            .colorWithCalibratedWhiteAlpha(
                1.0,
                0.18
            )
    );

    root.addSubview(
        barBackground
    );

    // ========================================================
    // BAR FILL
    // ========================================================

    const barFill =
        $.NSTextField.alloc
            .initWithFrame(
                $.NSMakeRect(
                    barX,
                    barY,
                    1,
                    barHeight
                )
            );

    barFill.setStringValue(
        $("")
    );

    barFill.setEditable(
        false
    );

    barFill.setSelectable(
        false
    );

    barFill.setBezeled(
        false
    );

    barFill.setDrawsBackground(
        true
    );

    barFill.setBackgroundColor(
        $.NSColor.whiteColor
    );

    root.addSubview(
        barFill
    );

    return {

        win:
            win,

        glitch:
            glitch,

        label:
            label,

        barFill:
            barFill,

        barX:
            barX,

        barY:
            barY,

        barWidth:
            barWidth,

        barHeight:
            barHeight,

        baseX:
            glitchBaseX,

        baseY:
            glitchBaseY
    };
}

// ============================================================
// FINAL REPLACEMENT-FACE JUMPSCARE
// ============================================================

function showFinalJump() {

    log(
        "Final shutdown jumpscare."
    );

    const frame =
        $.NSScreen.mainScreen.frame;

    const width =
        Number(
            frame.size.width
        );

    const height =
        Number(
            frame.size.height
        );

    const win =
        createBorderlessWindow(
            frame,
            FULLSCREEN_LEVEL + 20
        );

    const root =
        win.contentView;

    // ========================================================
    // SAME ATTACK STATIC
    // ========================================================

    const background =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    0,
                    0,
                    width,
                    height
                )
            );

    background.setImage(
        loadImage(
            FILES.attackStatic
        )
    );

    background.setImageScaling(
        $.NSImageScaleAxesIndependently
    );

    root.addSubview(
        background
    );

    // ========================================================
    // NEW FACE
    // ========================================================

    const size =
        560;

    const baseX =
        (
            width -
            size
        ) / 2;

    const baseY =
        (
            height -
            size
        ) / 2;

    const face =
        $.NSImageView.alloc
            .initWithFrame(
                $.NSMakeRect(
                    baseX,
                    baseY,
                    size,
                    size
                )
            );

    face.setImage(
        loadImage(
            FILES.shutdownFace
        )
    );

    face.setImageScaling(
        $.NSImageScaleProportionallyUpOrDown
    );

    root.addSubview(
        face
    );

    win.makeKeyAndOrderFront(
        null
    );

    NSApp.activateIgnoringOtherApps(
        true
    );

    pump(
        0.03
    );

    // Re-play ORIGINAL attack sound.
    const pid =
        playSound(
            FILES.attackSound
        );

    const started =
        Date.now();

    while (
        (
            Date.now() -
            started
        ) / 1000 <
        FINAL_JUMP_DURATION
    ) {

        face.setFrameOrigin(
            $.NSMakePoint(

                baseX +
                    randomBetween(
                        -14,
                        14
                    ),

                baseY +
                    randomBetween(
                        -14,
                        14
                    )
            )
        );

        pump(
            0.02
        );
    }

    hideWindow(
        win
    );

    // Do NOT stop attack sound.
    // Let it continue into shutdown.

    return pid;
}

// ============================================================
// NORMAL MAC SHUTDOWN
// ============================================================

function requestShutdown() {

    log(
        "Requesting macOS shutdown."
    );

    try {

        const systemEvents =
            Application(
                "System Events"
            );

        systemEvents.shutDown();

        log(
            "Shutdown request accepted."
        );

        return true;

    } catch (e) {

        log(
            "Direct shutdown failed: " +
            String(e)
        );
    }

    try {

        app.doShellScript(
            "/usr/bin/osascript " +
            "-e 'tell application \"System Events\" to shut down'"
        );

        log(
            "Fallback shutdown submitted."
        );

        return true;

    } catch (e) {

        log(
            "Fallback shutdown failed: " +
            String(e)
        );

        try {
            $.NSBeep();
        } catch (ignored) {}

        return false;
    }
}

// ============================================================
// POST STAGE
// ============================================================

function showPostStage(
    attack
) {

    log(
        "Entering popup/download stage."
    );

    const screen =
        $.NSScreen.mainScreen
            .visibleFrame;

    const sx =
        Number(
            screen.origin.x
        );

    const sy =
        Number(
            screen.origin.y
        );

    const sw =
        Number(
            screen.size.width
        );

    const sh =
        Number(
            screen.size.height
        );

    // ========================================================
    // ORIGINAL POPUP 1 — TELEPORT
    // ========================================================

    const p1w =
        380;

    const p1h =
        300;

    const popup1 =
        createPopup(
            "System Message",
            FILES.idiot,
            p1w,
            p1h,

            sx + 50,

            sy +
            sh * 0.55
        );

    // ========================================================
    // ORIGINAL POPUP 2 — DVD
    // ========================================================

    const p2w =
        270;

    const p2h =
        350;

    let dvdX =
        sx +
        sw * 0.42;

    let dvdY =
        sy +
        sh * 0.20;

    const popup2 =
        createPopup(
            "Image Viewer",
            FILES.taunt,
            p2w,
            p2h,
            dvdX,
            dvdY
        );

    // ========================================================
    // NEW SHAKE POPUP #1
    // FIRST NEW IMAGE
    // ========================================================

    const s1w =
        230;

    const s1h =
        410;

    const s1BaseX =
        sx +
        sw * 0.05;

    const s1BaseY =
        sy +
        sh * 0.18;

    const shake1 =
        createPopup(
            "Signal Error",
            FILES.shake1,
            s1w,
            s1h,
            s1BaseX,
            s1BaseY
        );

    // ========================================================
    // NEW SHAKE POPUP #2
    // FIRST IMAGE AGAIN
    // ========================================================

    const s2w =
        215;

    const s2h =
        385;

    const s2BaseX =
        sx +
        sw * 0.64;

    const s2BaseY =
        sy +
        sh * 0.40;

    const shake2 =
        createPopup(
            "System Warning",
            FILES.shake1,
            s2w,
            s2h,
            s2BaseX,
            s2BaseY
        );

    // ========================================================
    // NEW SHAKE POPUP #3
    // SECOND NEW IMAGE
    // ========================================================

    const s3w =
        360;

    const s3h =
        220;

    const s3BaseX =
        sx +
        sw * 0.47;

    const s3BaseY =
        sy +
        sh * 0.67;

    const shake3 =
        createPopup(
            "Signal Corruption",
            FILES.shake2,
            s3w,
            s3h,
            s3BaseX,
            s3BaseY
        );

    // ========================================================
    // SHOW ALL FIVE
    // ========================================================

    popup1.makeKeyAndOrderFront(
        null
    );

    popup2.orderFront(
        null
    );

    shake1.orderFront(
        null
    );

    shake2.orderFront(
        null
    );

    shake3.orderFront(
        null
    );

    NSApp.activateIgnoringOtherApps(
        true
    );

    pump(
        0.10
    );

    log(
        "Five popup windows displayed."
    );

    // ========================================================
    // STOP SIGNS
    // ========================================================

    const stopWindows =
        createStopSigns();

    log(
        "STOP overlays displayed."
    );

    // ========================================================
    // MOVEMENT
    // ========================================================

    let velocityX =
        7;

    let velocityY =
        5;

    if (
        Math.random() <
        0.5
    ) {

        velocityX =
            -velocityX;
    }

    if (
        Math.random() <
        0.5
    ) {

        velocityY =
            -velocityY;
    }

    let nextDvdFrame =
        Date.now();

    let nextShakeFrame =
        Date.now();

    let nextTeleport =
        Date.now() +
        TELEPORT_INTERVAL *
        1000;

    // ========================================================
    // ATTACK END
    // ========================================================

    const attackEndsAt =
        attack.started +
        attack.duration *
        1000;

    const downloadStartsAt =
        attack.started +
        Math.max(
            0,
            (
                attack.duration -
                DOWNLOAD_LEAD
            ) *
            1000
        );

    // ========================================================
    // POST SFX / AMBIENCE
    // ========================================================

    let postStarted =
        false;

    let postPID =
        0;

    let ambiencePID =
        0;

    // ========================================================
    // DOWNLOAD
    // ========================================================

    let overlay =
        null;

    let downloadStarted =
        false;

    let downloadComplete =
        false;

    let downloadStartedAt =
        0;

    let completionTime =
        0;

    // ========================================================
    // FINAL JUMPSCARE
    // ========================================================

    let finalJumpStarted =
        false;

    let finalJumpPID =
        0;

    let finalJumpAt =
        0;

    // ========================================================
    // SHUTDOWN
    // ========================================================

    let shutdownAt =
        0;

    let shutdownRequested =
        false;

    // ========================================================
    // LOOP
    // ========================================================

    const stageStarted =
        Date.now();

    while (
        (
            Date.now() -
            stageStarted
        ) / 1000 <
        POPUP_DURATION
    ) {

        const now =
            Date.now();

        // ====================================================
        // TELEPORT ORIGINAL POPUP
        // ====================================================

        if (
            now >=
            nextTeleport
        ) {

            nextTeleport =
                now +
                TELEPORT_INTERVAL *
                1000;

            if (
                isVisible(
                    popup1
                )
            ) {

                popup1.setFrameOrigin(
                    $.NSMakePoint(

                        randomBetween(
                            sx,
                            sx +
                            sw -
                            p1w
                        ),

                        randomBetween(
                            sy,
                            sy +
                            sh -
                            p1h
                        )
                    )
                );
            }
        }

        // ====================================================
        // DVD POPUP
        // ====================================================

        if (
            now >=
            nextDvdFrame
        ) {

            nextDvdFrame =
                now +
                DVD_FRAME_TIME *
                1000;

            if (
                isVisible(
                    popup2
                )
            ) {

                dvdX +=
                    velocityX;

                dvdY +=
                    velocityY;

                const minX =
                    sx;

                const minY =
                    sy;

                const maxX =
                    sx +
                    sw -
                    p2w;

                const maxY =
                    sy +
                    sh -
                    p2h;

                if (
                    dvdX <=
                    minX
                ) {

                    dvdX =
                        minX;

                    velocityX =
                        Math.abs(
                            velocityX
                        );
                }

                else if (
                    dvdX >=
                    maxX
                ) {

                    dvdX =
                        maxX;

                    velocityX =
                        -Math.abs(
                            velocityX
                        );
                }

                if (
                    dvdY <=
                    minY
                ) {

                    dvdY =
                        minY;

                    velocityY =
                        Math.abs(
                            velocityY
                        );
                }

                else if (
                    dvdY >=
                    maxY
                ) {

                    dvdY =
                        maxY;

                    velocityY =
                        -Math.abs(
                            velocityY
                        );
                }

                popup2.setFrameOrigin(
                    $.NSMakePoint(
                        dvdX,
                        dvdY
                    )
                );
            }
        }

        // ====================================================
        // THREE SHAKE POPUPS
        // ====================================================

        if (
            now >=
            nextShakeFrame
        ) {

            nextShakeFrame =
                now +
                SHAKE_FRAME_TIME *
                1000;

            if (
                isVisible(
                    shake1
                )
            ) {

                shake1.setFrameOrigin(
                    $.NSMakePoint(

                        s1BaseX +
                        randomBetween(
                            -7,
                            7
                        ),

                        s1BaseY +
                        randomBetween(
                            -7,
                            7
                        )
                    )
                );
            }

            if (
                isVisible(
                    shake2
                )
            ) {

                shake2.setFrameOrigin(
                    $.NSMakePoint(

                        s2BaseX +
                        randomBetween(
                            -7,
                            7
                        ),

                        s2BaseY +
                        randomBetween(
                            -7,
                            7
                        )
                    )
                );
            }

            if (
                isVisible(
                    shake3
                )
            ) {

                shake3.setFrameOrigin(
                    $.NSMakePoint(

                        s3BaseX +
                        randomBetween(
                            -6,
                            6
                        ),

                        s3BaseY +
                        randomBetween(
                            -6,
                            6
                        )
                    )
                );
            }
        }

        // ====================================================
        // DOWNLOAD START
        // ====================================================

        if (
            !downloadStarted &&
            now >=
            downloadStartsAt
        ) {

            overlay =
                createDownloadOverlay();

            overlay.win.orderFront(
                null
            );

            downloadStarted =
                true;

            downloadStartedAt =
                now;

            log(
                "2-second download overlay started."
            );
        }

        // ====================================================
        // ATTACK AUDIO FINISHES
        //
        // Start old post effect AND new ambience.
        // ====================================================

        if (
            !postStarted &&
            now >=
            attackEndsAt
        ) {

            postStarted =
                true;

            postPID =
                playSound(
                    FILES.postSound
                );

            ambiencePID =
                playSound(
                    FILES.ambience
                );

            log(
                "Post sound + layer3 ambience started."
            );
        }

        // ====================================================
        // UPDATE DOWNLOAD
        // ====================================================

        if (
            downloadStarted &&
            !downloadComplete &&
            overlay
        ) {

            const elapsed =
                now -
                downloadStartedAt;

            let percent =
                Math.floor(
                    (
                        elapsed /
                        (
                            DOWNLOAD_DURATION *
                            1000
                        )
                    ) *
                    100
                );

            percent =
                Math.max(
                    0,
                    Math.min(
                        100,
                        percent
                    )
                );

            overlay.label
                .setStringValue(
                    $(
                        "DOWNLOADING A-90... (" +
                        percent +
                        "%)"
                    )
                );

            const fillWidth =
                Math.max(
                    1,
                    overlay.barWidth *
                    (
                        percent /
                        100
                    )
                );

            overlay.barFill
                .setFrame(
                    $.NSMakeRect(
                        overlay.barX,
                        overlay.barY,
                        fillWidth,
                        overlay.barHeight
                    )
                );

            // Slight fullscreen shake.
            overlay.glitch
                .setFrameOrigin(
                    $.NSMakePoint(

                        overlay.baseX +
                        randomBetween(
                            -5,
                            5
                        ),

                        overlay.baseY +
                        randomBetween(
                            -5,
                            5
                        )
                    )
                );

            // =================================================
            // COMPLETE
            // =================================================

            if (
                percent >=
                100
            ) {

                downloadComplete =
                    true;

                completionTime =
                    now;

                hideWindow(
                    overlay.win
                );

                shutdownAt =
                    completionTime +
                    SHUTDOWN_DELAY *
                    1000;

                finalJumpAt =
                    shutdownAt -
                    FINAL_JUMP_LEAD *
                    1000;

                log(
                    "Download complete."
                );

                log(
                    "Final jumpscare scheduled shortly before shutdown."
                );

                log(
                    "Shutdown scheduled 3 seconds after completion."
                );
            }
        }

        // ====================================================
        // FINAL JUMPSCARE
        // ====================================================

        if (
            downloadComplete &&
            !finalJumpStarted &&
            now >=
            finalJumpAt
        ) {

            finalJumpStarted =
                true;

            // Stop ambience so the attack sound is clear.
            stopSound(
                ambiencePID
            );

            ambiencePID =
                0;

            finalJumpPID =
                showFinalJump();
        }

        // ====================================================
        // SHUTDOWN
        // ====================================================

        if (
            downloadComplete &&
            !shutdownRequested &&
            Date.now() >=
            shutdownAt
        ) {

            shutdownRequested =
                true;

            requestShutdown();

            break;
        }

        pump(
            0.025
        );
    }

    // ========================================================
    // CLEANUP
    // ========================================================

    stopSound(
        attack.pid
    );

    stopSound(
        postPID
    );

    stopSound(
        ambiencePID
    );

    // Leave final attack sound alone briefly if shutdown has
    // already been requested.

    if (
        !shutdownRequested
    ) {

        stopSound(
            finalJumpPID
        );
    }

    hideWindow(
        popup1
    );

    hideWindow(
        popup2
    );

    hideWindow(
        shake1
    );

    hideWindow(
        shake2
    );

    hideWindow(
        shake3
    );

    if (overlay) {

        hideWindow(
            overlay.win
        );
    }

    stopWindows.forEach(
        function (win) {

            hideWindow(
                win
            );
        }
    );
}

// ============================================================
// MAIN
// ============================================================

try {

    log(
        "Starting."
    );

    // --------------------------------------------------------
    // IMPORTANT:
    //
    // NO volume manipulation.
    //
    // Current Mac system volume is preserved.
    // --------------------------------------------------------

    showSpawn();

    log(
        "Desktop gap."
    );

    pump(
        DESKTOP_GAP
    );

    const attack =
        showAttack();

    log(
        "Attack visual complete."
    );

    showPostStage(
        attack
    );

    log(
        "Script finished."
    );

}
catch (e) {

    console.log(
        "\n[A90 ERROR]\n" +
        String(e) +
        "\n"
    );

    try {

        app.displayDialog(
            "A-90 script stopped:\n\n" +
            String(e),
            {
                buttons: [
                    "OK"
                ],

                defaultButton:
                    "OK"
            }
        );

    } catch (ignored) {}
}