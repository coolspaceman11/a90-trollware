Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

# ============================================================
# BASE FOLDER
#
# Portable:
# everything is loaded from beside this .ps1 file.
# ============================================================

$base = $PSScriptRoot

# ============================================================
# FILES
# ============================================================

$spawnSound =
    Join-Path $base "a-90-warning.mp3"

$attackSound =
    Join-Path $base "attack.wav"

$postSound =
    Join-Path $base "230b23a1-8641-46ea-a62d-c0ef5fe7ce64.wav"

$ambienceSound =
    Join-Path $base "layer3.wav"

$spawnStatic =
    Join-Path $base "static2png.png"

$spawnFace =
    Join-Path $base "ransom_idle(1).png"

$stopSign =
    Join-Path $base "stop_sign.png"

$attackStatic =
    Join-Path $base "static1.png"

$attackFace =
    Join-Path $base "ransom_attack.png"

$idiotImage =
    Join-Path $base "idiot.png"

$tauntImage =
    Join-Path $base "taunt2.jpg"

$downloadImage =
    Join-Path $base "taunt3.jpeg"

$shakeImage1 =
    Join-Path $base "shake_popup_1.png"

$shakeImage2 =
    Join-Path $base "shake_popup_2.png"

$desktopStopImage =
    Join-Path $base "desktop_stop.png"

$shutdownFace =
    Join-Path $base "shutdown_face.png"

# ============================================================
# TIMING
# ============================================================

$spawnFaceAtMs =
    300

$stopAtMs =
    650

$spawnTotalMs =
    2230

$desktopGapMs =
    400

# Attack picture lasts 0.6 sec.
$attackVisualMs =
    600

# Download begins 0.5 sec before attack.wav ends.
$downloadLeadMs =
    500

# NEW: download lasts only TWO seconds.
$downloadDurationMs =
    2000

# NEW: shutdown request occurs THREE seconds
# after progress reaches 100%.
$shutdownDelayMs =
    3000

# Final jumpscare lasts 0.65 sec.
$finalJumpDurationMs =
    650

# Therefore it starts 0.65 sec before shutdown.
$finalJumpStartMs =
    $shutdownDelayMs -
    $finalJumpDurationMs

# Maximum popup duration if shutdown never occurs.
$popupLifetimeMs =
    140000

$teleportIntervalMs =
    1000

# ============================================================
# CHECK FILES
# ============================================================

$requiredFiles = @(

    $spawnSound,
    $attackSound,
    $postSound,
    $ambienceSound,

    $spawnStatic,
    $spawnFace,
    $stopSign,

    $attackStatic,
    $attackFace,

    $idiotImage,
    $tauntImage,
    $downloadImage,

    $shakeImage1,
    $shakeImage2,

    $desktopStopImage,
    $shutdownFace
)

foreach ($file in $requiredFiles) {

    if (-not (Test-Path $file)) {

        Write-Host ""
        Write-Host "MISSING FILE:" -ForegroundColor Red
        Write-Host $file
        Write-Host ""

        Read-Host "Press Enter to exit"
        exit
    }
}

# ============================================================
# CLICK-THROUGH WINDOW SUPPORT
# ============================================================

if (-not ("A90WindowTools" -as [type])) {

    Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class A90WindowTools
{
    public const int GWL_EXSTYLE = -20;

    public const int WS_EX_TRANSPARENT = 0x00000020;
    public const int WS_EX_NOACTIVATE  = 0x08000000;

    [DllImport("user32.dll", SetLastError = true)]
    public static extern int GetWindowLong(
        IntPtr hWnd,
        int nIndex
    );

    [DllImport("user32.dll", SetLastError = true)]
    public static extern int SetWindowLong(
        IntPtr hWnd,
        int nIndex,
        int dwNewLong
    );
}
"@
}

function Set-WindowClickThrough {

    param(
        [System.Windows.Window]$Window
    )

    $helper =
        New-Object System.Windows.Interop.WindowInteropHelper(
            $Window
        )

    $handle =
        $helper.Handle

    $style =
        [A90WindowTools]::GetWindowLong(
            $handle,
            [A90WindowTools]::GWL_EXSTYLE
        )

    $style =
        $style `
        -bor [A90WindowTools]::WS_EX_TRANSPARENT `
        -bor [A90WindowTools]::WS_EX_NOACTIVATE

    [A90WindowTools]::SetWindowLong(
        $handle,
        [A90WindowTools]::GWL_EXSTYLE,
        $style
    ) | Out-Null
}

# ============================================================
# IMAGE LOADER
# ============================================================

function Load-Bitmap {

    param(
        [string]$Path
    )

    $bitmap =
        New-Object System.Windows.Media.Imaging.BitmapImage

    $bitmap.BeginInit()

    $bitmap.CacheOption =
        [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad

    $bitmap.UriSource =
        New-Object System.Uri(
            $Path
        )

    $bitmap.EndInit()

    $bitmap.Freeze()

    return $bitmap
}

# ============================================================
# WAV DURATION
# ============================================================

function Get-WavDurationMilliseconds {

    param(
        [string]$Path
    )

    try {

        $stream =
            [System.IO.File]::OpenRead(
                $Path
            )

        $reader =
            New-Object System.IO.BinaryReader(
                $stream
            )

        $reader.ReadBytes(4) | Out-Null
        $reader.ReadInt32() | Out-Null
        $reader.ReadBytes(4) | Out-Null

        $byteRate =
            0

        $dataSize =
            0

        while (
            $stream.Position -lt
            $stream.Length
        ) {

            if (
                (
                    $stream.Length -
                    $stream.Position
                ) -lt 8
            ) {

                break
            }

            $chunkID =
                [System.Text.Encoding]::ASCII.GetString(
                    $reader.ReadBytes(4)
                )

            $chunkSize =
                $reader.ReadInt32()

            if (
                $chunkID -eq
                "fmt "
            ) {

                $reader.ReadInt16() | Out-Null
                $reader.ReadInt16() | Out-Null
                $reader.ReadInt32() | Out-Null

                $byteRate =
                    $reader.ReadInt32()

                $remaining =
                    $chunkSize -
                    12

                if (
                    $remaining -gt
                    0
                ) {

                    $reader.ReadBytes(
                        $remaining
                    ) | Out-Null
                }
            }

            elseif (
                $chunkID -eq
                "data"
            ) {

                $dataSize =
                    $chunkSize

                $stream.Seek(
                    $chunkSize,
                    [System.IO.SeekOrigin]::Current
                ) | Out-Null
            }

            else {

                $stream.Seek(
                    $chunkSize,
                    [System.IO.SeekOrigin]::Current
                ) | Out-Null
            }

            if (
                (
                    $chunkSize %
                    2
                ) -ne 0
            ) {

                if (
                    $stream.Position -lt
                    $stream.Length
                ) {

                    $reader.ReadByte() | Out-Null
                }
            }
        }

        $reader.Close()
        $stream.Close()

        if (
            $byteRate -gt 0 -and
            $dataSize -gt 0
        ) {

            return [int](
                (
                    $dataSize /
                    $byteRate
                ) *
                1000
            )
        }
    }
    catch {}

    return 2610
}

$attackDurationMs =
    Get-WavDurationMilliseconds `
        $attackSound

# ============================================================
# AUDIO
#
# IMPORTANT:
# NOTHING changes Windows master volume anymore.
#
# Sounds use whatever volume Windows is already set to.
# ============================================================

$attackPlayer =
    New-Object System.Media.SoundPlayer

$attackPlayer.SoundLocation =
    $attackSound

$attackPlayer.Load()

$postPlayer =
    New-Object System.Media.SoundPlayer

$postPlayer.SoundLocation =
    $postSound

$postPlayer.Load()

$ambiencePlayer =
    New-Object System.Media.SoundPlayer

$ambiencePlayer.SoundLocation =
    $ambienceSound

$ambiencePlayer.Load()

$spawnPlayer =
    New-Object System.Windows.Media.MediaPlayer

$spawnPlayer.Open(
    (
        New-Object System.Uri(
            $spawnSound
        )
    )
)

# This does NOT alter Windows volume.
# It means 100% of the CURRENT system volume.
$spawnPlayer.Volume =
    1.0

Start-Sleep -Milliseconds 250

# ============================================================
# SPAWN PHASE
# ============================================================

function Show-SpawnPhase {

    $window =
        New-Object System.Windows.Window

    $window.WindowStyle =
        "None"

    $window.ResizeMode =
        "NoResize"

    $window.ShowInTaskbar =
        $false

    $window.Topmost =
        $true

    $window.WindowStartupLocation =
        "Manual"

    $window.Left =
        0

    $window.Top =
        0

    $window.Width =
        [System.Windows.SystemParameters]::PrimaryScreenWidth

    $window.Height =
        [System.Windows.SystemParameters]::PrimaryScreenHeight

    $window.Background =
        [System.Windows.Media.Brushes]::Black

    # ========================================================
    # ROOT
    # ========================================================

    $grid =
        New-Object System.Windows.Controls.Grid

    $window.Content =
        $grid

    # ========================================================
    # RED STATIC
    # ========================================================

    $static =
        New-Object System.Windows.Controls.Image

    $static.Source =
        Load-Bitmap $spawnStatic

    $static.Stretch =
        "Fill"

    $grid.Children.Add(
        $static
    ) | Out-Null

    # ========================================================
    # CANVAS
    # ========================================================

    $canvas =
        New-Object System.Windows.Controls.Canvas

    $grid.Children.Add(
        $canvas
    ) | Out-Null

    # ========================================================
    # SPAWN FACE
    # ========================================================

    $face =
        New-Object System.Windows.Controls.Image

    $face.Source =
        Load-Bitmap $spawnFace

    $face.Width =
        520

    $face.Height =
        520

    $face.Stretch =
        "Uniform"

    $face.Visibility =
        "Hidden"

    $faceTransform =
        New-Object System.Windows.Media.TranslateTransform

    $face.RenderTransform =
        $faceTransform

    $canvas.Children.Add(
        $face
    ) | Out-Null

    # ========================================================
    # STOP
    # ========================================================

    $stop =
        New-Object System.Windows.Controls.Image

    $stop.Source =
        Load-Bitmap $stopSign

    $stop.Width =
        285

    $stop.Height =
        285

    $stop.Stretch =
        "Uniform"

    $stop.Visibility =
        "Hidden"

    $canvas.Children.Add(
        $stop
    ) | Out-Null

    $random =
        New-Object System.Random

    # ========================================================
    # POSITION
    # ========================================================

    $window.Add_ContentRendered({

        [System.Windows.Controls.Canvas]::SetLeft(
            $face,
            (
                $window.ActualWidth -
                $face.Width
            ) / 2
        )

        [System.Windows.Controls.Canvas]::SetTop(
            $face,
            (
                $window.ActualHeight -
                $face.Height
            ) / 2
        )

        [System.Windows.Controls.Canvas]::SetLeft(
            $stop,
            (
                $window.ActualWidth -
                $stop.Width
            ) / 2
        )

        [System.Windows.Controls.Canvas]::SetTop(
            $stop,
            (
                $window.ActualHeight -
                $stop.Height
            ) / 2
        )
    })

    # ========================================================
    # TIMERS
    # ========================================================

    $faceTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $faceTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $spawnFaceAtMs
        )

    $stopTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $stopTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $stopAtMs
        )

    $shakeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $shakeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            28
        )

    $closeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $closeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $spawnTotalMs
        )

    # ========================================================
    # SHAKE
    # ========================================================

    $shakeTimer.Add_Tick({

        $faceTransform.X =
            $random.Next(
                -10,
                11
            )

        $faceTransform.Y =
            $random.Next(
                -10,
                11
            )
    })

    # ========================================================
    # FACE
    # ========================================================

    $faceTimer.Add_Tick({

        $faceTimer.Stop()

        $face.Visibility =
            "Visible"

        $shakeTimer.Start()
    })

    # ========================================================
    # STOP REPLACES FACE
    # ========================================================

    $stopTimer.Add_Tick({

        $stopTimer.Stop()

        $shakeTimer.Stop()

        $faceTransform.X =
            0

        $faceTransform.Y =
            0

        $face.Visibility =
            "Hidden"

        $stop.Visibility =
            "Visible"
    })

    # ========================================================
    # END
    # ========================================================

    $closeTimer.Add_Tick({

        $closeTimer.Stop()
        $faceTimer.Stop()
        $stopTimer.Stop()
        $shakeTimer.Stop()

        $spawnPlayer.Stop()

        $window.Close()
    })

    # ========================================================
    # START
    # ========================================================

    $window.Add_Loaded({

        $spawnPlayer.Position =
            [TimeSpan]::Zero

        $spawnPlayer.Play()

        $faceTimer.Start()
        $stopTimer.Start()
        $closeTimer.Start()
    })

    $window.ShowDialog() |
        Out-Null
}

# ============================================================
# ATTACK PHASE
# ============================================================

function Show-AttackPhase {

    $window =
        New-Object System.Windows.Window

    $window.WindowStyle =
        "None"

    $window.ResizeMode =
        "NoResize"

    $window.ShowInTaskbar =
        $false

    $window.Topmost =
        $true

    $window.WindowStartupLocation =
        "Manual"

    $window.Left =
        0

    $window.Top =
        0

    $window.Width =
        [System.Windows.SystemParameters]::PrimaryScreenWidth

    $window.Height =
        [System.Windows.SystemParameters]::PrimaryScreenHeight

    $grid =
        New-Object System.Windows.Controls.Grid

    $window.Content =
        $grid

    # ========================================================
    # ATTACK STATIC
    # ========================================================

    $static =
        New-Object System.Windows.Controls.Image

    $static.Source =
        Load-Bitmap $attackStatic

    $static.Stretch =
        "Fill"

    $grid.Children.Add(
        $static
    ) | Out-Null

    # ========================================================
    # FACE CANVAS
    # ========================================================

    $canvas =
        New-Object System.Windows.Controls.Canvas

    $grid.Children.Add(
        $canvas
    ) | Out-Null

    $face =
        New-Object System.Windows.Controls.Image

    $face.Source =
        Load-Bitmap $attackFace

    $face.Width =
        600

    $face.Height =
        600

    $face.Stretch =
        "Uniform"

    $transform =
        New-Object System.Windows.Media.TranslateTransform

    $face.RenderTransform =
        $transform

    $canvas.Children.Add(
        $face
    ) | Out-Null

    $window.Add_ContentRendered({

        [System.Windows.Controls.Canvas]::SetLeft(
            $face,
            (
                $window.ActualWidth -
                $face.Width
            ) / 2
        )

        [System.Windows.Controls.Canvas]::SetTop(
            $face,
            (
                $window.ActualHeight -
                $face.Height
            ) / 2
        )
    })

    $random =
        New-Object System.Random

    $shakeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $shakeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            25
        )

    $shakeTimer.Add_Tick({

        $transform.X =
            $random.Next(
                -12,
                13
            )

        $transform.Y =
            $random.Next(
                -12,
                13
            )
    })

    $closeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $closeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $attackVisualMs
        )

    $closeTimer.Add_Tick({

        $closeTimer.Stop()
        $shakeTimer.Stop()

        $window.Close()
    })

    $window.Add_Loaded({

        # Preloaded.
        $attackPlayer.Play()

        $shakeTimer.Start()
        $closeTimer.Start()
    })

    $window.ShowDialog() |
        Out-Null
}

# ============================================================
# CREATE NORMAL TITLED POPUP
# ============================================================

function New-A90Popup {

    param(
        [string]$Title,
        [string]$ImagePath,
        [double]$Width,
        [double]$Height,
        [double]$Left,
        [double]$Top
    )

    $window =
        New-Object System.Windows.Window

    $window.Title =
        $Title

    $window.Width =
        $Width

    $window.Height =
        $Height

    $window.WindowStyle =
        "SingleBorderWindow"

    $window.ResizeMode =
        "NoResize"

    $window.WindowStartupLocation =
        "Manual"

    $window.Left =
        $Left

    $window.Top =
        $Top

    $window.Topmost =
        $true

    $window.ShowInTaskbar =
        $true

    $image =
        New-Object System.Windows.Controls.Image

    $image.Source =
        Load-Bitmap $ImagePath

    $image.Stretch =
        "Uniform"

    $image.Margin =
        "4"

    $window.Content =
        $image

    return $window
}

# ============================================================
# CREATE CLICK-THROUGH STOP SIGN
# ============================================================

function New-StopOverlay {

    param(
        [double]$Left,
        [double]$Top,
        [double]$Size
    )

    $window =
        New-Object System.Windows.Window

    $window.WindowStyle =
        "None"

    $window.ResizeMode =
        "NoResize"

    $window.ShowInTaskbar =
        $false

    $window.Topmost =
        $true

    $window.AllowsTransparency =
        $true

    $window.Background =
        [System.Windows.Media.Brushes]::Transparent

    $window.WindowStartupLocation =
        "Manual"

    $window.Left =
        $Left

    $window.Top =
        $Top

    $window.Width =
        $Size

    $window.Height =
        $Size

    $image =
        New-Object System.Windows.Controls.Image

    $image.Source =
        Load-Bitmap $desktopStopImage

    $image.Stretch =
        "Uniform"

    $window.Content =
        $image

    $window.Add_SourceInitialized({

        Set-WindowClickThrough `
            $window
    })

    $window.Show()

    return $window
}

# ============================================================
# CREATE TASKBAR + DESKTOP STOP SIGNS
#
# Click-through:
# they visually cover areas but do not block clicks.
# ============================================================

function New-AllStopOverlays {

    $results =
        New-Object System.Collections.ArrayList

    $screenWidth =
        [System.Windows.SystemParameters]::PrimaryScreenWidth

    $screenHeight =
        [System.Windows.SystemParameters]::PrimaryScreenHeight

    # ========================================================
    # BOTTOM TASKBAR
    # ========================================================

    $taskbarStopSize =
        80

    $fractions = @(

        0.15,
        0.27,
        0.39,
        0.51,
        0.63,
        0.75,
        0.87
    )

    foreach (
        $fraction in
        $fractions
    ) {

        $left =
            (
                $screenWidth *
                $fraction
            ) -
            (
                $taskbarStopSize /
                2
            )

        $top =
            $screenHeight -
            $taskbarStopSize -
            2

        $stop =
            New-StopOverlay `
                -Left $left `
                -Top $top `
                -Size $taskbarStopSize

        [void]$results.Add(
            $stop
        )
    }

    # ========================================================
    # WINDOWS DESKTOP ICON AREA
    #
    # Desktop icons normally begin down the LEFT side.
    # ========================================================

    $desktopStopSize =
        70

    $desktopYs = @(

        45,
        135,
        225,
        315,
        405,
        495
    )

    foreach (
        $y in
        $desktopYs
    ) {

        if (
            (
                $y +
                $desktopStopSize
            ) -lt
            (
                $screenHeight -
                90
            )
        ) {

            $stop =
                New-StopOverlay `
                    -Left 12 `
                    -Top $y `
                    -Size $desktopStopSize

            [void]$results.Add(
                $stop
            )
        }
    }

    return $results
}

# ============================================================
# DOWNLOAD OVERLAY
# ============================================================

function New-DownloadOverlay {

    $window =
        New-Object System.Windows.Window

    $window.WindowStyle =
        "None"

    $window.ResizeMode =
        "NoResize"

    $window.ShowInTaskbar =
        $false

    $window.Topmost =
        $true

    $window.AllowsTransparency =
        $true

    $window.Background =
        [System.Windows.Media.Brushes]::Transparent

    $window.WindowStartupLocation =
        "Manual"

    $window.Left =
        0

    $window.Top =
        0

    $window.Width =
        [System.Windows.SystemParameters]::PrimaryScreenWidth

    $window.Height =
        [System.Windows.SystemParameters]::PrimaryScreenHeight

    $window.Add_SourceInitialized({

        Set-WindowClickThrough `
            $window
    })

    # ========================================================
    # ROOT
    # ========================================================

    $root =
        New-Object System.Windows.Controls.Grid

    $window.Content =
        $root

    # ========================================================
    # TRANSPARENT GLITCH
    # ========================================================

    $glitch =
        New-Object System.Windows.Controls.Image

    $glitch.Source =
        Load-Bitmap $downloadImage

    $glitch.Stretch =
        "Fill"

    $glitch.Opacity =
        0.30

    $glitch.Margin =
        "-10"

    $glitchTransform =
        New-Object System.Windows.Media.TranslateTransform

    $glitch.RenderTransform =
        $glitchTransform

    $root.Children.Add(
        $glitch
    ) | Out-Null

    # ========================================================
    # CENTER PANEL
    # ========================================================

    $panel =
        New-Object System.Windows.Controls.Border

    $panel.Width =
        650

    $panel.Padding =
        "25"

    $panel.CornerRadius =
        "8"

    $panel.HorizontalAlignment =
        "Center"

    $panel.VerticalAlignment =
        "Center"

    $panel.Background =
        New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.Color]::FromArgb(
                210,
                0,
                0,
                0
            )
        )

    $root.Children.Add(
        $panel
    ) | Out-Null

    $stack =
        New-Object System.Windows.Controls.StackPanel

    $panel.Child =
        $stack

    # ========================================================
    # LABEL
    # ========================================================

    $label =
        New-Object System.Windows.Controls.TextBlock

    $label.Text =
        "DOWNLOADING A-90... (0%)"

    $label.FontSize =
        26

    $label.FontWeight =
        "Bold"

    $label.Foreground =
        [System.Windows.Media.Brushes]::White

    $label.HorizontalAlignment =
        "Center"

    $label.Margin =
        "0,0,0,16"

    $stack.Children.Add(
        $label
    ) | Out-Null

    # ========================================================
    # PROGRESS
    # ========================================================

    $progress =
        New-Object System.Windows.Controls.ProgressBar

    $progress.Width =
        580

    $progress.Height =
        30

    $progress.Minimum =
        0

    $progress.Maximum =
        100

    $progress.Value =
        0

    $stack.Children.Add(
        $progress
    ) | Out-Null

    return [PSCustomObject]@{

        Window =
            $window

        Glitch =
            $glitch

        Transform =
            $glitchTransform

        Label =
            $label

        Progress =
            $progress
    }
}

# ============================================================
# FINAL JUMPSCARE WINDOW
# ============================================================

function New-FinalJumpWindow {

    $window =
        New-Object System.Windows.Window

    $window.WindowStyle =
        "None"

    $window.ResizeMode =
        "NoResize"

    $window.ShowInTaskbar =
        $false

    $window.Topmost =
        $true

    $window.WindowStartupLocation =
        "Manual"

    $window.Left =
        0

    $window.Top =
        0

    $window.Width =
        [System.Windows.SystemParameters]::PrimaryScreenWidth

    $window.Height =
        [System.Windows.SystemParameters]::PrimaryScreenHeight

    $root =
        New-Object System.Windows.Controls.Grid

    $window.Content =
        $root

    # ========================================================
    # ATTACK STATIC AGAIN
    # ========================================================

    $background =
        New-Object System.Windows.Controls.Image

    $background.Source =
        Load-Bitmap $attackStatic

    $background.Stretch =
        "Fill"

    $root.Children.Add(
        $background
    ) | Out-Null

    # ========================================================
    # REPLACEMENT FACE
    # ========================================================

    $canvas =
        New-Object System.Windows.Controls.Canvas

    $root.Children.Add(
        $canvas
    ) | Out-Null

    $face =
        New-Object System.Windows.Controls.Image

    $face.Source =
        Load-Bitmap $shutdownFace

    $face.Width =
        560

    $face.Height =
        560

    $face.Stretch =
        "Uniform"

    $transform =
        New-Object System.Windows.Media.TranslateTransform

    $face.RenderTransform =
        $transform

    $canvas.Children.Add(
        $face
    ) | Out-Null

    $window.Add_ContentRendered({

        [System.Windows.Controls.Canvas]::SetLeft(
            $face,
            (
                $window.ActualWidth -
                $face.Width
            ) / 2
        )

        [System.Windows.Controls.Canvas]::SetTop(
            $face,
            (
                $window.ActualHeight -
                $face.Height
            ) / 2
        )
    })

    return [PSCustomObject]@{

        Window =
            $window

        Face =
            $face

        Transform =
            $transform
    }
}

# ============================================================
# POST-ATTACK STAGE
# ============================================================

function Show-PostStage {

    param(
        [int]$DownloadDelayMs,
        [int]$PostSoundDelayMs
    )

    $workArea =
        [System.Windows.SystemParameters]::WorkArea

    $random =
        New-Object System.Random

    # ========================================================
    # ORIGINAL POPUP 1 — TELEPORT
    # ========================================================

    $popup1 =
        New-A90Popup `
            -Title "System Message" `
            -ImagePath $idiotImage `
            -Width 380 `
            -Height 300 `
            -Left (
                $workArea.Left +
                45
            ) `
            -Top (
                $workArea.Top +
                $workArea.Height *
                0.50
            )

    # ========================================================
    # ORIGINAL POPUP 2 — DVD BOUNCE
    # ========================================================

    $popup2 =
        New-A90Popup `
            -Title "Image Viewer" `
            -ImagePath $tauntImage `
            -Width 270 `
            -Height 350 `
            -Left (
                $workArea.Left +
                $workArea.Width *
                0.40
            ) `
            -Top (
                $workArea.Top +
                $workArea.Height *
                0.16
            )

    # ========================================================
    # NEW SHAKE POPUP 1
    # ========================================================

    $shake1 =
        New-A90Popup `
            -Title "Signal Error" `
            -ImagePath $shakeImage1 `
            -Width 230 `
            -Height 410 `
            -Left (
                $workArea.Left +
                $workArea.Width *
                0.05
            ) `
            -Top (
                $workArea.Top +
                $workArea.Height *
                0.16
            )

    # ========================================================
    # NEW SHAKE POPUP 2
    #
    # SAME FIRST IMAGE.
    # ========================================================

    $shake2 =
        New-A90Popup `
            -Title "System Warning" `
            -ImagePath $shakeImage1 `
            -Width 215 `
            -Height 385 `
            -Left (
                $workArea.Left +
                $workArea.Width *
                0.67
            ) `
            -Top (
                $workArea.Top +
                $workArea.Height *
                0.34
            )

    # ========================================================
    # NEW SHAKE POPUP 3
    #
    # SECOND GLITCH IMAGE.
    # ========================================================

    $shake3 =
        New-A90Popup `
            -Title "Signal Corruption" `
            -ImagePath $shakeImage2 `
            -Width 360 `
            -Height 220 `
            -Left (
                $workArea.Left +
                $workArea.Width *
                0.47
            ) `
            -Top (
                $workArea.Top +
                $workArea.Height *
                0.66
            )

    # ========================================================
    # BASE LOCATIONS FOR SHAKE WINDOWS
    # ========================================================

    $shakeBases =
        [PSCustomObject]@{

            X1 = $shake1.Left
            Y1 = $shake1.Top

            X2 = $shake2.Left
            Y2 = $shake2.Top

            X3 = $shake3.Left
            Y3 = $shake3.Top
        }

    # ========================================================
    # SHOW ALL FIVE
    # ========================================================

    $popup1.Show()
    $popup2.Show()

    $shake1.Show()
    $shake2.Show()
    $shake3.Show()

    # ========================================================
    # STOP SIGNS
    # ========================================================

    $stopWindows =
        New-AllStopOverlays

    # ========================================================
    # TELEPORT TIMER
    # ========================================================

    $teleportTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $teleportTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $teleportIntervalMs
        )

    $teleportTimer.Add_Tick({

        if (
            $popup1.IsVisible
        ) {

            $maxX =
                [Math]::Max(
                    $workArea.Left + 1,
                    $workArea.Right -
                    $popup1.Width
                )

            $maxY =
                [Math]::Max(
                    $workArea.Top + 1,
                    $workArea.Bottom -
                    $popup1.Height
                )

            $popup1.Left =
                $random.Next(
                    [int]$workArea.Left,
                    [int]$maxX
                )

            $popup1.Top =
                $random.Next(
                    [int]$workArea.Top,
                    [int]$maxY
                )
        }
    })

    # ========================================================
    # DVD BOUNCE
    # ========================================================

    $dvdMotion =
        [PSCustomObject]@{

            X = 7.0
            Y = 5.0
        }

    if (
        $random.Next(
            0,
            2
        ) -eq 0
    ) {

        $dvdMotion.X =
            -$dvdMotion.X
    }

    if (
        $random.Next(
            0,
            2
        ) -eq 0
    ) {

        $dvdMotion.Y =
            -$dvdMotion.Y
    }

    $bounceTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $bounceTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            40
        )

    $bounceTimer.Add_Tick({

        if (
            -not
            $popup2.IsVisible
        ) {

            return
        }

        $newX =
            $popup2.Left +
            $dvdMotion.X

        $newY =
            $popup2.Top +
            $dvdMotion.Y

        $minX =
            $workArea.Left

        $minY =
            $workArea.Top

        $maxX =
            $workArea.Right -
            $popup2.Width

        $maxY =
            $workArea.Bottom -
            $popup2.Height

        if (
            $newX -le
            $minX
        ) {

            $newX =
                $minX

            $dvdMotion.X =
                [Math]::Abs(
                    $dvdMotion.X
                )
        }

        elseif (
            $newX -ge
            $maxX
        ) {

            $newX =
                $maxX

            $dvdMotion.X =
                -[Math]::Abs(
                    $dvdMotion.X
                )
        }

        if (
            $newY -le
            $minY
        ) {

            $newY =
                $minY

            $dvdMotion.Y =
                [Math]::Abs(
                    $dvdMotion.Y
                )
        }

        elseif (
            $newY -ge
            $maxY
        ) {

            $newY =
                $maxY

            $dvdMotion.Y =
                -[Math]::Abs(
                    $dvdMotion.Y
                )
        }

        $popup2.Left =
            $newX

        $popup2.Top =
            $newY
    })

    # ========================================================
    # THREE SHAKE WINDOWS
    # ========================================================

    $shakeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $shakeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            65
        )

    $shakeTimer.Add_Tick({

        if (
            $shake1.IsVisible
        ) {

            $shake1.Left =
                $shakeBases.X1 +
                $random.Next(
                    -7,
                    8
                )

            $shake1.Top =
                $shakeBases.Y1 +
                $random.Next(
                    -7,
                    8
                )
        }

        if (
            $shake2.IsVisible
        ) {

            $shake2.Left =
                $shakeBases.X2 +
                $random.Next(
                    -7,
                    8
                )

            $shake2.Top =
                $shakeBases.Y2 +
                $random.Next(
                    -7,
                    8
                )
        }

        if (
            $shake3.IsVisible
        ) {

            $shake3.Left =
                $shakeBases.X3 +
                $random.Next(
                    -6,
                    7
                )

            $shake3.Top =
                $shakeBases.Y3 +
                $random.Next(
                    -6,
                    7
                )
        }
    })

    # ========================================================
    # DOWNLOAD OVERLAY
    # ========================================================

    $overlay =
        New-DownloadOverlay

    $downloadClock =
        New-Object System.Diagnostics.Stopwatch

    $overlayShakeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $overlayShakeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            30
        )

    $overlayShakeTimer.Add_Tick({

        $overlay.Transform.X =
            $random.Next(
                -5,
                6
            )

        $overlay.Transform.Y =
            $random.Next(
                -5,
                6
            )
    })

    # ========================================================
    # STATE
    # ========================================================

    $state =
        [PSCustomObject]@{

            DownloadStarted =
                $false

            DownloadComplete =
                $false

            PostSoundStarted =
                $false

            FinalJumpStarted =
                $false

            ShutdownRequested =
                $false

            Done =
                $false
        }

    # ========================================================
    # DOWNLOAD DELAY
    # ========================================================

    if (
        $DownloadDelayMs -lt
        1
    ) {

        $DownloadDelayMs =
            1
    }

    $downloadDelayTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $downloadDelayTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $DownloadDelayMs
        )

    $downloadDelayTimer.Add_Tick({

        $downloadDelayTimer.Stop()

        $state.DownloadStarted =
            $true

        $overlay.Progress.Value =
            0

        $overlay.Label.Text =
            "DOWNLOADING A-90... (0%)"

        $downloadClock.Restart()

        $overlay.Window.Show()

        $overlayShakeTimer.Start()
    })

    # ========================================================
    # DOWNLOAD PROGRESS
    # ========================================================

    $downloadTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $downloadTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            30
        )

    $completionClock =
        New-Object System.Diagnostics.Stopwatch

    $downloadTimer.Add_Tick({

        if (
            -not
            $state.DownloadStarted
        ) {

            return
        }

        if (
            $state.DownloadComplete
        ) {

            return
        }

        $percent =
            [Math]::Floor(
                (
                    $downloadClock.ElapsedMilliseconds /
                    $downloadDurationMs
                ) *
                100
            )

        $percent =
            [Math]::Max(
                0,
                [Math]::Min(
                    100,
                    $percent
                )
            )

        $overlay.Progress.Value =
            $percent

        $overlay.Label.Text =
            "DOWNLOADING A-90... ($percent%)"

        if (
            $percent -ge
            100
        ) {

            $state.DownloadComplete =
                $true

            $downloadTimer.Stop()
            $overlayShakeTimer.Stop()

            $downloadClock.Stop()

            $overlay.Transform.X =
                0

            $overlay.Transform.Y =
                0

            $overlay.Window.Hide()

            # Start the 3-second shutdown countdown.
            $completionClock.Restart()
        }
    })

    # ========================================================
    # POST ATTACK AUDIO DELAY
    # ========================================================

    if (
        $PostSoundDelayMs -lt
        1
    ) {

        $PostSoundDelayMs =
            1
    }

    $postSoundTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $postSoundTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $PostSoundDelayMs
        )

    $postSoundTimer.Add_Tick({

        $postSoundTimer.Stop()

        if (
            -not
            $state.PostSoundStarted
        ) {

            $state.PostSoundStarted =
                $true

            # Existing post-attack SFX.
            $postPlayer.Play()

            # NEW ambience starts after attack.
            $ambiencePlayer.Play()
        }
    })

    # ========================================================
    # FINAL SHUTDOWN JUMPSCARE
    # ========================================================

    $finalJump =
        New-FinalJumpWindow

    $finalShakeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $finalShakeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            20
        )

    $finalShakeTimer.Add_Tick({

        $finalJump.Transform.X =
            $random.Next(
                -14,
                15
            )

        $finalJump.Transform.Y =
            $random.Next(
                -14,
                15
            )
    })

    $finalCloseTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $finalCloseTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $finalJumpDurationMs
        )

    $finalCloseTimer.Add_Tick({

        $finalCloseTimer.Stop()
        $finalShakeTimer.Stop()

        $finalJump.Transform.X =
            0

        $finalJump.Transform.Y =
            0

        if (
            $finalJump.Window.IsVisible
        ) {

            $finalJump.Window.Close()
        }
    })

    # ========================================================
    # SHUTDOWN COUNTDOWN TIMER
    # ========================================================

    $shutdownTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $shutdownTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            25
        )

    $shutdownTimer.Add_Tick({

        if (
            -not
            $state.DownloadComplete
        ) {

            return
        }

        # ----------------------------------------------------
        # FINAL JUMPSCARE
        # ----------------------------------------------------

        if (
            -not
            $state.FinalJumpStarted -and
            $completionClock.ElapsedMilliseconds -ge
            $finalJumpStartMs
        ) {

            $state.FinalJumpStarted =
                $true

            # Stop ambience so final attack audio is clearer.
            $ambiencePlayer.Stop()

            # Re-play attack.wav.
            $attackPlayer.Play()

            # NEW replacement face.
            $finalJump.Window.Show()

            $finalJump.Window.Activate()

            $finalShakeTimer.Start()
            $finalCloseTimer.Start()
        }

        # ----------------------------------------------------
        # SHUTDOWN AT THREE SECONDS
        # ----------------------------------------------------

        if (
            -not
            $state.ShutdownRequested -and
            $completionClock.ElapsedMilliseconds -ge
            $shutdownDelayMs
        ) {

            $state.ShutdownRequested =
                $true

            $completionClock.Stop()

            # =================================================
            # NORMAL WINDOWS SHUTDOWN REQUEST
            #
            # No /f flag:
            # unsaved applications are allowed to intervene.
            # =================================================

            try {

                & "$env:SystemRoot\System32\shutdown.exe" `
                    /s `
                    /f 
                    /t 0
            }
            catch {

                Write-Host `
                    "Windows shutdown request failed." `
                    -ForegroundColor Red
            }

            # Don't force-close programs ourselves.
            $state.Done =
                $true
        }
    })

    # ========================================================
    # MAXIMUM LIFETIME
    # ========================================================

    $lifetimeTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $lifetimeTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            $popupLifetimeMs
        )

    $lifetimeTimer.Add_Tick({

        $lifetimeTimer.Stop()

        $state.Done =
            $true
    })

    # ========================================================
    # START
    # ========================================================

    $teleportTimer.Start()
    $bounceTimer.Start()
    $shakeTimer.Start()

    $downloadDelayTimer.Start()
    $downloadTimer.Start()
    $postSoundTimer.Start()

    $shutdownTimer.Start()
    $lifetimeTimer.Start()

    # ========================================================
    # DISPATCHER FRAME
    # ========================================================

    $frame =
        New-Object System.Windows.Threading.DispatcherFrame

    $watchTimer =
        New-Object System.Windows.Threading.DispatcherTimer

    $watchTimer.Interval =
        [TimeSpan]::FromMilliseconds(
            50
        )

    $watchTimer.Add_Tick({

        if (
            $state.Done
        ) {

            $watchTimer.Stop()

            $teleportTimer.Stop()
            $bounceTimer.Stop()
            $shakeTimer.Stop()

            $downloadDelayTimer.Stop()
            $downloadTimer.Stop()

            $overlayShakeTimer.Stop()
            $postSoundTimer.Stop()

            $shutdownTimer.Stop()
            $lifetimeTimer.Stop()

            $finalShakeTimer.Stop()
            $finalCloseTimer.Stop()

            # -------------------------------------------------
            # CLOSE OUR OWN WINDOWS ONLY.
            # -------------------------------------------------

            if (
                $overlay.Window.IsVisible
            ) {

                $overlay.Window.Close()
            }

            if (
                $popup1.IsVisible
            ) {

                $popup1.Close()
            }

            if (
                $popup2.IsVisible
            ) {

                $popup2.Close()
            }

            if (
                $shake1.IsVisible
            ) {

                $shake1.Close()
            }

            if (
                $shake2.IsVisible
            ) {

                $shake2.Close()
            }

            if (
                $shake3.IsVisible
            ) {

                $shake3.Close()
            }

            foreach (
                $stopWindow in
                $stopWindows
            ) {

                if (
                    $stopWindow.IsVisible
                ) {

                    $stopWindow.Close()
                }
            }

            # Leave final attack audio alone if shutdown
            # has already been requested.

            if (
                -not
                $state.ShutdownRequested
            ) {

                $attackPlayer.Stop()
            }

            $postPlayer.Stop()
            $ambiencePlayer.Stop()

            $frame.Continue =
                $false
        }
    })

    $watchTimer.Start()

    [System.Windows.Threading.Dispatcher]::PushFrame(
        $frame
    )
}

# ============================================================
# MAIN
# ============================================================

# ============================================================
# 1. SPAWN
# ============================================================

Show-SpawnPhase

# ============================================================
# 2. NORMAL DESKTOP FOR 0.4 SEC
# ============================================================

Start-Sleep `
    -Milliseconds $desktopGapMs

# ============================================================
# 3. ATTACK
# ============================================================

Show-AttackPhase

# ============================================================
# 4. POST STAGE TIMING
#
# Attack visual has already consumed 600ms.
#
# Download:
# starts 500ms BEFORE attack.wav finishes.
#
# Post SFX + ambience:
# start when attack.wav finishes.
# ============================================================

$downloadDelayMs =
    $attackDurationMs `
    - $attackVisualMs `
    - $downloadLeadMs

$postSoundDelayMs =
    $attackDurationMs `
    - $attackVisualMs

if (
    $downloadDelayMs -lt
    1
) {

    $downloadDelayMs =
        1
}

if (
    $postSoundDelayMs -lt
    1
) {

    $postSoundDelayMs =
        1
}

Show-PostStage `
    -DownloadDelayMs $downloadDelayMs `
    -PostSoundDelayMs $postSoundDelayMs

exit